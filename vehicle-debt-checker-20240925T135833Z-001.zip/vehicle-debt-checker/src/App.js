import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './Layout';
import VehicleDebtChecker from './VehicleDebtChecker';
import FAQPage from './FAQPage';
import ContactPage from './ContactPage';
import CommonQuestionsPage from './CommonQuestionsPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<VehicleDebtChecker />} />
          <Route path="faq" element={<FAQPage />} />
          <Route path="contact" element={<ContactPage />} />
          <Route path="common-questions" element={<CommonQuestionsPage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;