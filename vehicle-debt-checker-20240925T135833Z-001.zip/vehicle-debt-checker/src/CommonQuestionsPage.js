import React from 'react';

const QuestionItem = ({ question, answer }) => (
  <div className="mb-6">
    <h3 className="text-lg font-semibold text-gray-800 mb-2">{question}</h3>
    <p className="text-gray-600">{answer}</p>
  </div>
);

export default function CommonQuestionsPage() {
  const questions = [
    {
      question: "Quanto tempo leva para processar o pagamento dos débitos?",
      answer: "O processamento do pagamento é geralmente imediato, mas pode levar até 24 horas para ser refletido no sistema do órgão responsável."
    },
    {
      question: "Posso parcelar o pagamento dos débitos?",
      answer: "Sim, oferecemos opções de parcelamento através do nosso sistema de pagamento. As condições variam de acordo com o valor total dos débitos."
    },
    {
      question: "O que fazer se houver discrepância nos valores dos débitos?",
      answer: "Se você notar qualquer discrepância nos valores, entre em contato conosco imediatamente através da nossa página de contato. Faremos uma verificação detalhada."
    },
    {
      question: "Com que frequência devo consultar os débitos do meu veículo?",
      answer: "Recomendamos consultar os débitos pelo menos uma vez por mês para evitar surpresas e manter seu veículo regularizado."
    },
    {
      question: "Posso obter um comprovante de pagamento?",
      answer: "Sim, após a conclusão do pagamento, você receberá um comprovante por email. Este documento também ficará disponível na sua conta em nosso sistema."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">Perguntas Frequentes</h1>
        <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
          {questions.map((item, index) => (
            <QuestionItem key={index} question={item.question} answer={item.answer} />
          ))}
        </div>
      </div>
    </div>
  );
}