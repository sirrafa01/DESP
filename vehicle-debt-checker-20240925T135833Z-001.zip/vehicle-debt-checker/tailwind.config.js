module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      gradientColorStops: theme => ({
        'blue': theme('colors.blue.500'),
        'purple': theme('colors.purple.600'),
      })
    },
  },
  plugins: [],
}